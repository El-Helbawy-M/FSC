import 'package:fuodz/models/category.dart';

class Search {
  String type = "";
  Category category;

  Search({
    this.type = "",
    this.category,
  });
}
